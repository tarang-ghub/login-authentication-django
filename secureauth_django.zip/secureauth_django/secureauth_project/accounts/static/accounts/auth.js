// Login / Sign-up tab switching (only runs on the auth page)

const card = document.querySelector(".card[data-mode]");

if (card) {
  const tabs = document.querySelectorAll(".tab");
  const panels = document.querySelectorAll(".panel");

  function show(name) {
    tabs.forEach(t => t.classList.toggle("active", t.dataset.target === name));
    panels.forEach(p => p.classList.toggle("active", p.id === name));
  }

  tabs.forEach(t => t.addEventListener("click", () => show(t.dataset.target)));
  show(card.dataset.mode === "signup" ? "signup" : "login");
}

// Ask for confirmation before deleting an account (dashboard page)

const deleteForm = document.getElementById("delete-form");

if (deleteForm) {
  deleteForm.addEventListener("submit", e => {

    if (!confirm("Delete your account permanently? This cannot be undone.")) {
      e.preventDefault();
    }
    
  });
}
