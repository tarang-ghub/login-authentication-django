from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from .forms import SignUpForm

def auth_page(request, mode="login"):
    """
    Shows the login/sign-up page and handles both form submissions.
    """
    if request.user.is_authenticated:
        return redirect("dashboard")

    login_form = AuthenticationForm(request)
    signup_form = SignUpForm()

    if request.method == "POST":
        if mode == "signup":
            signup_form = SignUpForm(request.POST)
            if signup_form.is_valid():
                user = signup_form.save()      # saved to the database, password hashed
                login(request, user)           # log them in right away
                return redirect("dashboard")
        else:
            login_form = AuthenticationForm(request, data=request.POST)
            if login_form.is_valid():
                login(request, login_form.get_user())
                return redirect("dashboard")

    return render(request, "accounts/auth.html", {
        "login_form": login_form,
        "signup_form": signup_form,
        "mode": mode,
    })


@login_required
def dashboard(request):
    return render(request, "accounts/dashboard.html")


@require_POST
def logout_view(request):
    logout(request)
    return redirect("login")


@login_required
@require_POST
def delete_account(request):
    user = request.user
    logout(request)
    user.delete()
    return redirect("login")
