from django.urls import path
from . import views

urlpatterns = [
    path("", views.auth_page, name="login"),
    path("signup/", views.auth_page, {"mode": "signup"}, name="signup"),
    path("dashboard/", views.dashboard, name="dashboard"),
    path("logout/", views.logout_view, name="logout"),
    path("delete-account/", views.delete_account, name="delete_account"),
]
